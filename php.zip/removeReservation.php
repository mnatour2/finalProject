<?php

	if($_SERVER['REQUEST_METHOD'] == "POST"){
		// Get data
		$room_id = isset($_POST['room_id']) ? $_POST['room_id'] : "";


		$server_name = "localhost";
		$username = "root";
		$password = "";
		$dbname = "hotel_management";
		$response  = array();
		
		$conn = new mysqli($server_name, $username, $password, $dbname);
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 
		
		$sql = "delete from reservations where room_id='$room_id';";



		if ($conn->query($sql) === TRUE) {
			$response['error'] = false;
			$response['message'] = "reservation removed successfully!";
		} else {
			$response['error'] = true;
			$response['message'] = "Error, " . $conn->error;
			
		}
		echo json_encode($response);

		$conn->close();
	
	}


?>