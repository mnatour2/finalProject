<?php

	if($_SERVER['REQUEST_METHOD'] == "POST"){
		// Get data
		$firstName = isset($_POST['firstName']) ? $_POST['firstName'] : "";
		$lastName = isset($_POST['lastName']) ? $_POST['lastName'] : "";
		$usernameC = isset($_POST['usernameC']) ? $_POST['usernameC'] : "";
		$passwordC = isset($_POST['passwordC']) ? $_POST['passwordC'] : "";


		$server_name = "localhost";
		$username = "root";
		$password = "";
		$dbname = "hotel_management";
		$response  = array();
		
		$conn = new mysqli($server_name, $username, $password, $dbname);
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 
		
		$sql = "insert into customers values ( '" . $firstName . "' , '" . $lastName . "' , '" . $usernameC . "' , '" . $passwordC . "', '0','0')";


		if ($conn->query($sql) === TRUE) {
			$response['error'] = false;
			$response['message'] = "customer added successfully!";
		} else {
			$response['error'] = true;
			$response['message'] = "Error, " . $conn->error;
			
		}
		echo json_encode($response);

		$conn->close();
	
	}


?>